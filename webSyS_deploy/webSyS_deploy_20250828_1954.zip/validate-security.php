<?php
/**
 * Suite de Validación de Seguridad - webSyS
 * Servicios y Sistemas SRL
 * 
 * Script de validación integral para verificar todas las correcciones de seguridad
 * Ejecuta tests automatizados para cada vulnerabilidad corregida
 */

// Configuración del script
ini_set('display_errors', 1);
error_reporting(E_ALL);
set_time_limit(300); // 5 minutos

// Colores para output en terminal
class Colors {
    public static $GREEN = "\033[0;32m";
    public static $RED = "\033[0;31m";
    public static $YELLOW = "\033[0;33m";
    public static $BLUE = "\033[0;34m";
    public static $NC = "\033[0m"; // No Color
    
    // Para modo no-color (entornos que no soportan colores)
    public static function init($useColors = true) {
        if (!$useColors) {
            self::$GREEN = self::$RED = self::$YELLOW = self::$BLUE = self::$NC = '';
        }
    }
}

// Inicializar colores (detectar si es terminal)
Colors::init(php_sapi_name() === 'cli');

// Cargar dependencias necesarias
require_once('config/env.php');
require_once('includes/security-init.php');

/**
 * Clase principal para validación de seguridad
 */
class SecurityValidator {
    
    private static $testResults = [];
    private static $totalTests = 0;
    private static $passedTests = 0;
    private static $failedTests = 0;
    
    /**
     * Registra resultado de test
     */
    private static function recordTest($testName, $passed, $details = '') {
        self::$totalTests++;
        if ($passed) {
            self::$passedTests++;
            echo Colors::$GREEN . "✅ PASS: " . Colors::$NC . "$testName\n";
        } else {
            self::$failedTests++;
            echo Colors::$RED . "❌ FAIL: " . Colors::$NC . "$testName\n";
            if ($details) {
                echo Colors::$YELLOW . "   Details: $details" . Colors::$NC . "\n";
            }
        }
        
        self::$testResults[] = [
            'name' => $testName,
            'passed' => $passed,
            'details' => $details
        ];
    }
    
    /**
     * Valida configuración de variables de entorno
     */
    public static function validateEnvironmentConfig() {
        echo Colors::$BLUE . "\n🔧 VALIDANDO CONFIGURACIÓN DE ENTORNO..." . Colors::$NC . "\n";
        
        // Test 1: Verificar que el archivo .env existe
        $envExists = file_exists('.env');
        self::recordTest(
            'Archivo .env existe',
            $envExists,
            $envExists ? '' : 'Archivo .env no encontrado'
        );
        
        if (!$envExists) return false;
        
        // Test 2: Verificar que APP_SALT no sea el valor por defecto
        $appSalt = getEnvVar('APP_SALT');
        $saltSecure = !empty($appSalt) && 
                     strlen($appSalt) >= 32 && 
                     $appSalt !== 'salt_serviciosysistemas' &&
                     $appSalt !== 'default_salt_change_in_production';
        
        self::recordTest(
            'APP_SALT configurado de forma segura',
            $saltSecure,
            $saltSecure ? '' : 'Salt inseguro o muy corto'
        );
        
        // Test 3: Verificar que ALLOWED_ORIGINS esté configurado
        $corsOrigins = getEnvVar('ALLOWED_ORIGINS');
        $corsConfigured = !empty($corsOrigins) && $corsOrigins !== '*';
        
        self::recordTest(
            'CORS configurado restrictivamente',
            $corsConfigured,
            $corsConfigured ? '' : 'CORS no restrictivo o no configurado'
        );
        
        // Test 4: Verificar directorio de logs
        $logDir = getEnvVar('LOG_DIR', '../private/logs');
        $logDirExists = is_dir($logDir);
        
        self::recordTest(
            'Directorio de logs configurado y existe',
            $logDirExists,
            $logDirExists ? '' : "Directorio $logDir no existe"
        );
        
        // Test 5: Verificar configuración de rate limiting
        $rateLimitMax = (int)getEnvVar('RATE_LIMIT_MAX', 0);
        $rateLimitWindow = (int)getEnvVar('RATE_LIMIT_WINDOW', 0);
        $rateLimitConfigured = $rateLimitMax > 0 && $rateLimitWindow > 0;
        
        self::recordTest(
            'Rate limiting configurado',
            $rateLimitConfigured,
            $rateLimitConfigured ? '' : 'Variables de rate limiting no configuradas'
        );
        
        return true;
    }
    
    /**
     * Valida protección CSRF
     */
    public static function testCSRFProtection() {
        echo Colors::$BLUE . "\n🛡️  VALIDANDO PROTECCIÓN CSRF..." . Colors::$NC . "\n";
        
        try {
            // Test 1: Verificar que la clase CSRFProtection existe
            $classExists = class_exists('CSRFProtection');
            self::recordTest(
                'Clase CSRFProtection disponible',
                $classExists,
                $classExists ? '' : 'Clase CSRFProtection no encontrada'
            );
            
            if (!$classExists) return false;
            
            // Test 2: Generar token CSRF
            if (session_status() !== PHP_SESSION_ACTIVE) {
                session_start();
            }
            
            $token = CSRFProtection::generateToken('test_action');
            $tokenGenerated = !empty($token) && is_string($token);
            
            self::recordTest(
                'Generación de token CSRF',
                $tokenGenerated,
                $tokenGenerated ? '' : 'No se pudo generar token CSRF'
            );
            
            if (!$tokenGenerated) return false;
            
            // Test 3: Validar token correcto
            $validToken = CSRFProtection::validateToken($token, 'test_action', false);
            self::recordTest(
                'Validación de token CSRF correcto',
                $validToken,
                $validToken ? '' : 'Token válido rechazado'
            );
            
            // Test 4: Rechazar token incorrecto
            $invalidToken = CSRFProtection::validateToken('token_invalido', 'test_action', false);
            self::recordTest(
                'Rechazo de token CSRF inválido',
                !$invalidToken,
                $invalidToken ? 'Token inválido aceptado' : ''
            );
            
            // Test 5: Generar campo HTML
            $htmlField = CSRFProtection::getTokenField('test_form');
            $htmlGenerated = !empty($htmlField) && strpos($htmlField, 'csrf_token') !== false;
            
            self::recordTest(
                'Generación de campo HTML CSRF',
                $htmlGenerated,
                $htmlGenerated ? '' : 'Campo HTML no generado correctamente'
            );
            
        } catch (Exception $e) {
            self::recordTest(
                'Test CSRF sin errores',
                false,
                'Excepción: ' . $e->getMessage()
            );
            return false;
        }
        
        return true;
    }
    
    /**
     * Verifica rate limiting
     */
    public static function testRateLimiting() {
        echo Colors::$BLUE . "\n⏱️  VALIDANDO RATE LIMITING..." . Colors::$NC . "\n";
        
        try {
            // Test 1: Verificar que la clase RateLimiter existe
            $classExists = class_exists('RateLimiter');
            self::recordTest(
                'Clase RateLimiter disponible',
                $classExists,
                $classExists ? '' : 'Clase RateLimiter no encontrada'
            );
            
            if (!$classExists) return false;
            
            // Test 2: Verificar límites con IP de test
            $testIP = '127.0.0.1';
            $testAction = 'security_test';
            
            // Limpiar estado previo
            RateLimiter::reset($testIP, $testAction);
            
            // Verificar que inicialmente permite
            $allowed = RateLimiter::checkLimit($testIP, $testAction, 2, 60);
            self::recordTest(
                'Rate limiting permite inicialmente',
                $allowed,
                $allowed ? '' : 'Rate limiting bloquea incorrectamente'
            );
            
            // Test 3: Registrar intentos hasta el límite
            RateLimiter::logAttempt($testIP, $testAction);
            RateLimiter::logAttempt($testIP, $testAction);
            
            $blocked = !RateLimiter::checkLimit($testIP, $testAction, 2, 60);
            self::recordTest(
                'Rate limiting bloquea después del límite',
                $blocked,
                $blocked ? '' : 'Rate limiting no bloquea correctamente'
            );
            
            // Test 4: Verificar estado de bloqueo
            $isBlocked = RateLimiter::isBlocked($testIP, $testAction);
            self::recordTest(
                'Status de bloqueo correcto',
                $isBlocked,
                $isBlocked ? '' : 'Estado de bloqueo incorrecto'
            );
            
            // Test 5: Verificar información de estado
            $status = RateLimiter::getStatus($testIP, $testAction);
            $statusValid = is_array($status) && isset($status['blocked']) && isset($status['attempts']);
            
            self::recordTest(
                'Información de estado disponible',
                $statusValid,
                $statusValid ? '' : 'Información de estado inválida'
            );
            
            // Limpiar para no interferir con otros tests
            RateLimiter::reset($testIP, $testAction);
            
        } catch (Exception $e) {
            self::recordTest(
                'Test Rate Limiting sin errores',
                false,
                'Excepción: ' . $e->getMessage()
            );
            return false;
        }
        
        return true;
    }
    
    /**
     * Valida sanitización de entrada
     */
    public static function testInputValidation() {
        echo Colors::$BLUE . "\n🔍 VALIDANDO SANITIZACIÓN DE ENTRADA..." . Colors::$NC . "\n";
        
        try {
            // Test 1: Verificar que la clase InputValidator existe
            $classExists = class_exists('InputValidator');
            self::recordTest(
                'Clase InputValidator disponible',
                $classExists,
                $classExists ? '' : 'Clase InputValidator no encontrada'
            );
            
            if (!$classExists) return false;
            
            // Test 2: Validación de email
            $validEmail = InputValidator::validateEmail('test@example.com');
            $invalidEmail = InputValidator::validateEmail('invalid-email');
            
            self::recordTest(
                'Validación de email válido',
                $validEmail,
                $validEmail ? '' : 'Email válido rechazado'
            );
            
            self::recordTest(
                'Rechazo de email inválido',
                !$invalidEmail,
                $invalidEmail ? 'Email inválido aceptado' : ''
            );
            
            // Test 3: Sanitización de strings
            $maliciousInput = '<script>alert("xss")</script>';
            $sanitized = InputValidator::sanitizeString($maliciousInput);
            $xssBlocked = strpos($sanitized, '<script>') === false;
            
            self::recordTest(
                'Sanitización previene XSS',
                $xssBlocked,
                $xssBlocked ? '' : 'XSS no bloqueado: ' . $sanitized
            );
            
            // Test 4: Prevención de inyección de headers de email
            $maliciousHeader = "test@example.com\nBCC: attacker@evil.com";
            $cleanHeader = InputValidator::sanitizeEmailHeader($maliciousHeader);
            $headerInjectionBlocked = strpos($cleanHeader, 'BCC:') === false;
            
            self::recordTest(
                'Prevención de inyección de headers',
                $headerInjectionBlocked,
                $headerInjectionBlocked ? '' : 'Header injection no bloqueada'
            );
            
            // Test 5: Detección de contenido sospechoso
            $suspiciousContent = 'javascript:alert(1)';
            $isSuspicious = InputValidator::isSuspicious($suspiciousContent);
            
            self::recordTest(
                'Detección de contenido sospechoso',
                $isSuspicious,
                $isSuspicious ? '' : 'Contenido sospechoso no detectado'
            );
            
            // Test 6: Validación de formulario completo
            $validFormData = [
                'nombre' => 'Juan Pérez',
                'email' => 'juan@example.com',
                'telefono' => '+54 9 11 1234-5678',
                'empresa' => 'Test Company',
                'mensaje' => 'Este es un mensaje de prueba válido para testing.'
            ];
            
            $validation = InputValidator::validateContactForm($validFormData);
            
            self::recordTest(
                'Validación de formulario válido',
                $validation['valid'],
                $validation['valid'] ? '' : 'Formulario válido rechazado: ' . implode(', ', $validation['errors'] ?? [])
            );
            
        } catch (Exception $e) {
            self::recordTest(
                'Test Input Validation sin errores',
                false,
                'Excepción: ' . $e->getMessage()
            );
            return false;
        }
        
        return true;
    }
    
    /**
     * Verifica seguridad del router
     */
    public static function testRouterSecurity() {
        echo Colors::$BLUE . "\n🚦 VALIDANDO SEGURIDAD DEL ROUTER..." . Colors::$NC . "\n";
        
        // Test 1: Verificar que router.php existe
        $routerExists = file_exists('router.php');
        self::recordTest(
            'Archivo router.php existe',
            $routerExists,
            $routerExists ? '' : 'router.php no encontrado'
        );
        
        if (!$routerExists) return false;
        
        // Test 2: Verificar que contiene whitelist
        $routerContent = file_get_contents('router.php');
        $hasWhitelist = strpos($routerContent, 'allowedFiles') !== false;
        
        self::recordTest(
            'Router contiene whitelist de archivos',
            $hasWhitelist,
            $hasWhitelist ? '' : 'Whitelist no encontrada en router'
        );
        
        // Test 3: Verificar protección contra path traversal
        $hasPathProtection = strpos($routerContent, '..') !== false &&
                            strpos($routerContent, 'path traversal') !== false;
        
        self::recordTest(
            'Router tiene protección path traversal',
            $hasPathProtection,
            $hasPathProtection ? '' : 'Protección path traversal no encontrada'
        );
        
        // Test 4: Verificar uso de realpath()
        $usesRealpath = strpos($routerContent, 'realpath') !== false;
        
        self::recordTest(
            'Router usa realpath() para validación',
            $usesRealpath,
            $usesRealpath ? '' : 'realpath() no usado para validación'
        );
        
        // Test 5: Verificar logging de seguridad
        $hasSecurityLogging = strpos($routerContent, 'SimpleLogger::logSecurityEvent') !== false ||
                             strpos($routerContent, 'logSecurityEvent') !== false;
        
        self::recordTest(
            'Router registra eventos de seguridad',
            $hasSecurityLogging,
            $hasSecurityLogging ? '' : 'Logging de seguridad no implementado'
        );
        
        return true;
    }
    
    /**
     * Valida logging seguro
     */
    public static function testLoggingSecurity() {
        echo Colors::$BLUE . "\n📝 VALIDANDO LOGGING SEGURO..." . Colors::$NC . "\n";
        
        try {
            // Test 1: Verificar que SimpleLogger existe
            $loggerExists = class_exists('SimpleLogger');
            self::recordTest(
                'Clase SimpleLogger disponible',
                $loggerExists,
                $loggerExists ? '' : 'Clase SimpleLogger no encontrada'
            );
            
            if (!$loggerExists) return false;
            
            // Test 2: Verificar directorio de logs fuera de webroot
            $logDir = getEnvVar('LOG_DIR', '../private/logs');
            $isOutsideWebroot = strpos($logDir, '../') !== false || strpos($logDir, '/private/') !== false;
            
            self::recordTest(
                'Logs fuera del directorio web',
                $isOutsideWebroot,
                $isOutsideWebroot ? '' : 'Logs en directorio web público'
            );
            
            // Test 3: Inicializar logger
            $loggerInit = SimpleLogger::init();
            self::recordTest(
                'Logger inicialización exitosa',
                $loggerInit,
                $loggerInit ? '' : 'Error al inicializar logger'
            );
            
            if (!$loggerInit) return false;
            
            // Test 4: Test de logging con datos sensibles
            $sensitiveData = 'password=secret123 y token=abc123xyz';
            SimpleLogger::info('Test message with sensitive data: ' . $sensitiveData);
            
            // Verificar que se creó el log
            $logFiles = glob($logDir . '/system_*.log');
            $logCreated = !empty($logFiles);
            
            self::recordTest(
                'Logs se crean correctamente',
                $logCreated,
                $logCreated ? '' : 'Archivos de log no creados'
            );
            
            // Test 5: Verificar que datos sensibles están sanitizados
            if ($logCreated) {
                $latestLog = end($logFiles);
                $logContent = file_get_contents($latestLog);
                $dataSanitized = strpos($logContent, 'secret123') === false && 
                               strpos($logContent, 'abc123xyz') === false;
                
                self::recordTest(
                    'Datos sensibles sanitizados en logs',
                    $dataSanitized,
                    $dataSanitized ? '' : 'Datos sensibles no sanitizados'
                );
            }
            
            // Test 6: Test de logging de eventos de seguridad
            SimpleLogger::logSecurityEvent('Test security event', ['test' => 'data']);
            
            $securityLogFiles = glob($logDir . '/security_*.log');
            $securityLogCreated = !empty($securityLogFiles);
            
            self::recordTest(
                'Logs de seguridad funcionan',
                $securityLogCreated,
                $securityLogCreated ? '' : 'Logs de seguridad no creados'
            );
            
        } catch (Exception $e) {
            self::recordTest(
                'Test Logging sin errores',
                false,
                'Excepción: ' . $e->getMessage()
            );
            return false;
        }
        
        return true;
    }
    
    /**
     * Verifica permisos de archivos y directorios
     */
    public static function testFilePermissions() {
        echo Colors::$BLUE . "\n🔐 VALIDANDO PERMISOS DE ARCHIVOS..." . Colors::$NC . "\n";
        
        // Test 1: Verificar que ../private/ existe y no es accesible vía web
        $privateDir = '../private';
        $privateDirExists = is_dir($privateDir);
        
        self::recordTest(
            'Directorio ../private/ existe',
            $privateDirExists,
            $privateDirExists ? '' : 'Directorio private no encontrado'
        );
        
        if ($privateDirExists) {
            // Test 2: Verificar permisos del directorio private
            $perms = fileperms($privateDir) & 0777;
            $correctPerms = $perms === 0750 || $perms === 0755;
            
            self::recordTest(
                'Permisos de ../private/ correctos',
                $correctPerms,
                $correctPerms ? '' : sprintf('Permisos incorrectos: %o', $perms)
            );
            
            // Test 3: Verificar .htaccess en directorio private
            $htaccessExists = file_exists($privateDir . '/.htaccess');
            self::recordTest(
                'Protección .htaccess en ../private/',
                $htaccessExists,
                $htaccessExists ? '' : '.htaccess no encontrado en directorio private'
            );
        }
        
        // Test 4: Verificar permisos de logs
        $logDir = getEnvVar('LOG_DIR', '../private/logs');
        if (is_dir($logDir)) {
            $logPerms = fileperms($logDir) & 0777;
            $correctLogPerms = $logPerms === 0750 || $logPerms === 0755;
            
            self::recordTest(
                'Permisos del directorio de logs correctos',
                $correctLogPerms,
                $correctLogPerms ? '' : sprintf('Permisos incorrectos: %o', $logPerms)
            );
            
            // Test 5: Verificar permisos de archivos de log
            $logFiles = glob($logDir . '/*.log');
            $logFilePermsOk = true;
            
            foreach ($logFiles as $logFile) {
                $filePerms = fileperms($logFile) & 0777;
                if ($filePerms !== 0640 && $filePerms !== 0644) {
                    $logFilePermsOk = false;
                    break;
                }
            }
            
            self::recordTest(
                'Permisos de archivos de log correctos',
                $logFilePermsOk,
                $logFilePermsOk ? '' : 'Algunos archivos de log tienen permisos incorrectos'
            );
        }
        
        // Test 6: Verificar que .env no es público
        $envExists = file_exists('.env');
        if ($envExists) {
            $envPerms = fileperms('.env') & 0777;
            $envSecure = $envPerms === 0600 || $envPerms === 0644;
            
            self::recordTest(
                'Archivo .env con permisos seguros',
                $envSecure,
                $envSecure ? '' : sprintf('Permisos .env inseguros: %o', $envPerms)
            );
        }
        
        return true;
    }
    
    /**
     * Ejecuta todos los tests de seguridad
     */
    public static function runAllSecurityTests() {
        echo Colors::$BLUE . "🔒 INICIANDO SUITE DE VALIDACIÓN DE SEGURIDAD - webSyS" . Colors::$NC . "\n";
        echo Colors::$BLUE . "================================================================" . Colors::$NC . "\n";
        
        $startTime = microtime(true);
        
        // Ejecutar todos los tests
        self::validateEnvironmentConfig();
        self::testCSRFProtection();
        self::testRateLimiting();
        self::testInputValidation();
        self::testRouterSecurity();
        self::testLoggingSecurity();
        self::testFilePermissions();
        
        $endTime = microtime(true);
        $executionTime = round($endTime - $startTime, 2);
        
        // Mostrar resumen final
        echo Colors::$BLUE . "\n================================================================" . Colors::$NC . "\n";
        echo Colors::$BLUE . "RESUMEN DE VALIDACIÓN DE SEGURIDAD" . Colors::$NC . "\n";
        echo Colors::$BLUE . "================================================================" . Colors::$NC . "\n";
        
        echo "⏱️  Tiempo de ejecución: {$executionTime} segundos\n";
        echo "📊 Tests ejecutados: " . self::$totalTests . "\n";
        echo Colors::$GREEN . "✅ Tests pasados: " . self::$passedTests . Colors::$NC . "\n";
        echo Colors::$RED . "❌ Tests fallidos: " . self::$failedTests . Colors::$NC . "\n";
        
        $successRate = self::$totalTests > 0 ? round((self::$passedTests / self::$totalTests) * 100, 1) : 0;
        echo "📈 Tasa de éxito: {$successRate}%\n\n";
        
        if (self::$failedTests === 0) {
            echo Colors::$GREEN . "🎉 ¡TODOS LOS TESTS DE SEGURIDAD PASARON!" . Colors::$NC . "\n";
            echo Colors::$GREEN . "   El sistema está listo para producción." . Colors::$NC . "\n\n";
            return 0; // Exit code success
        } else {
            echo Colors::$RED . "⚠️  ALGUNOS TESTS FALLARON" . Colors::$NC . "\n";
            echo Colors::$RED . "   Revisar y corregir antes de despliegue en producción." . Colors::$NC . "\n\n";
            
            // Mostrar detalles de tests fallidos
            echo Colors::$YELLOW . "TESTS FALLIDOS:" . Colors::$NC . "\n";
            foreach (self::$testResults as $result) {
                if (!$result['passed'] && $result['details']) {
                    echo Colors::$RED . "- " . $result['name'] . ": " . $result['details'] . Colors::$NC . "\n";
                }
            }
            echo "\n";
            
            return 1; // Exit code error
        }
    }
}

// Ejecutar tests si el script se ejecuta directamente
if (php_sapi_name() === 'cli' || basename($_SERVER['SCRIPT_NAME']) === 'validate-security.php') {
    $exitCode = SecurityValidator::runAllSecurityTests();
    exit($exitCode);
}

?>